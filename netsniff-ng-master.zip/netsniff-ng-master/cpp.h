#ifndef CPP_H
#define CPP_H

extern int cpp_exec(char *in_file, char *out_file, size_t out_len, char *const argv[]);

#endif
