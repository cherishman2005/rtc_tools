#ifndef STUN_H
#define STUN_H

extern int print_stun_probe(char *server, int sport, int tport);

#endif /* STUN_H */
