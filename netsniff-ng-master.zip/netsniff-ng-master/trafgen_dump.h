#ifndef TRAFGEN_DUMP_H
#define TRAFGEN_DUMP_H

#include "trafgen_conf.h"

extern int packet_dump_fd(struct packet *pkt, int fd);

#endif /* TRAFGEN_DUMP_H */
