#ifndef IOSCHED_H
#define IOSCHED_H

extern void ioprio_print(void);
extern void set_ioprio_rt(void);
extern void set_ioprio_be(void);

#endif /* IOSCHED_H */
